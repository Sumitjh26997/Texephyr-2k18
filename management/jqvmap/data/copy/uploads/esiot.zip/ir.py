import RPi.GPIO as IO
import time

IO.setmode(IO.BCM)
IO.setup(21,IO.OUT)
IO.setup(26,IO.IN)

try:
    while True:
        if(IO.input(26)==1):
            IO.output(21,True)
            print("IR detected")
            time.sleep(1)
        else:
            IO.output(21,False)
            print("normal")
            time.sleep(1)
           
            
            

except:
                IO.cleanup()

