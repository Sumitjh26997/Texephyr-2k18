import RPi.GPIO as IO
import time

brightness = 100
IO.setmode(IO.BCM)
IO.setup(21, IO.OUT)
IO.setup(25, IO.OUT)
pwm = IO.PWM(21, brightness)
pwm.start(0)
sign = -1

try:
    while True:
        if brightness < 10:
            sign = 1
            
        elif brightness > 90:
            sign = -1
            
        time.sleep(1)
        brightness = brightness+10*sign
        pwm.ChangeDutyCycle(brightness)
        time.sleep(0.1)
            
except KeyboardInterrupt:
    IO.cleanup()