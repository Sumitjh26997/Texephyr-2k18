import RPi.GPIO as IO
import time

IO.setmode(IO.BOARD)
IO.setup(12,IO.OUT)
IO.setup(26,IO.IN)

try:
    while True:
        if(IO.input(26)==0):
            IO.output(12,True)
            print("rain coming")
            time.sleep(1)
        else:
            IO.output(12,False)
            print("normal")
            time.sleep(1)
           
            
            

except:
                IO.cleanup()


