import RPi.GPIO as IO
import time

IO.setmode(IO.BOARD)
IO.setup(12,IO.OUT)
IO.setup(16,IO.OUT)

try:
    while True:
            IO.output(12,True)
            IO.output(16,False)
            time.sleep(2)
            IO.output(12,False)
            IO.output(16,True)
            time.sleep(2)

except KeyboardInterrupt:
                IO.cleanup()
