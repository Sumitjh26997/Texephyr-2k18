import RPi.GPIO as IO
import time

brightness = 100
IO.setmode(IO.BCM)
IO.setup(21, IO.OUT)
IO.setup(25, IO.OUT)
pwm = IO.PWM(21,30)
pwm.start(0)
sign = -1

try:
    while True:
     
            
        time.sleep(1)
        for i in range(100):
            pwm.ChangeDutyCycle(i)
            time.sleep(0.1)
            
except KeyboardInterrupt:
    IO.cleanup()
