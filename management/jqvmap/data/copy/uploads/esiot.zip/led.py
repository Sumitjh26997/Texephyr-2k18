import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BOARD)
GPIO.setup(21,GPIO.OUT)
GPIO.setup(26,GPIO.IN)
GPIO.setup(24,GPIO.OUT)
counter=0
try:
    while(True):
        time.sleep(0.5)
        if(GPIO.input(26)==1):
            GPIO.output(24,True)
            print("IR detected")
            counter+=1
            if(counter==5):
                GPIO.output(21,True)
                break                           
        else:
           print("Normal")
           GPIO.output(21,False)
           GPIO.output(24,False)
    while(True):
        GPIO.output(21,True)
        
      
except KeyboardInterrupt:
    GPIO.cleanup()